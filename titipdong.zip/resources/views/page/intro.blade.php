  <!--==========================
    Intro Section
  ============================-->
  <section id="intro" class="clearfix">
        <div class="container">
    
          <div class="intro-img">
            <img src="{{ asset('img/intro-img.svg')}}" alt="" class="img-fluid">
          </div>
    
          <div class="intro-info">
            <h2>Mau nitip?<br><span>TitipDong</span> solusinya</h2>
            <div>
              <a href="#about" class="btn-get-started scrollto">Jelajahi</a>
            </div>
          </div>
    
        </div>
</section><!-- #intro -->