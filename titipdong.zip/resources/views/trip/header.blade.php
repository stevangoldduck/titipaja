<section style="min-height:110px;background-color:#0069c7;margin-top:80px;padding-top:20px;">
        <div class="container">
            <h2 style="color:white;font-weight:500">Cari Barang Semaunya</h2>
        </div>
</section>