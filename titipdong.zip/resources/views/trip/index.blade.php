@extends('layout')

@section('title')
    TitipDong.com | Daftar Trip
@endsection
@include('header')

@section('content')

@include('trip.header')

@include('trip.search')

@include('footer')
@stop